<?php

interface Dropbox_Closure_ReRunnableActionInterface
{
    public function run();
}
