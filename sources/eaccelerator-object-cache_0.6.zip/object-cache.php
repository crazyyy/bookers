<?php
 
/*
Name: eAccelerator for WordPress
Description: eAccelerator backend for the WP Object Cache.
Version: 0.6
URI: http://neosmart.net/dl.php?id=13
Author: Computer Guru
Author URI: http://neosmart.net/blog/
 
* Install this file to /wp-content/object-cache.php
* If on Windows, restart IIS after installing for best results
 
Thanks to Ryan Boren for his original memcached code.
 
*/
 
// Gracefully revert to default cache if eAccelerator is not installed
if ( !function_exists('eaccelerator_get') )
    include_once(ABSPATH . WPINC . '/cache.php');
else
{

function wp_cache_add($key, $data, $flag = '', $expire = 0)
{
	return wp_cache_set($key, $data, $flag, $expire);
}

function wp_cache_close()
{
	return true;
}

function wp_cache_delete($id, $flag = '')
{
	global $wp_object_cache;

	return $wp_object_cache->delete($id, $flag);
}

function wp_cache_flush()
{
	global $wp_object_cache;

	return $wp_object_cache->flush();
}

function wp_cache_get($id, $flag = '')
{
	global $wp_object_cache;

	return $wp_object_cache->get($id, $flag);
}

function wp_cache_init()
{
	global $wp_object_cache;

	$wp_object_cache = new WP_Object_Cache();
}

function wp_cache_replace($key, $data, $flag = '', $expire = 0)
{
	return wp_cache_set($key, $data, $flag, $expire);
}

function wp_cache_set($key, $data, $flag = '', $expire = 0)
{
	global $wp_object_cache;

	return $wp_object_cache->set($key, $data, $flag, $expire);
}

class WP_Object_Cache {
	var $global_groups = array ('users', 'userlogins', 'usermeta');
	var $cache = array();

	function delete($id, $group = 'default')
	{
		$key = $this->key($id, $group);
		$result = eaccelerator_rm($key);
		if ( $result )
				unset($this->cache[$key]);
		return $result;
	}

	function flush()
	{
		eaccelerator_clear();
		return true;
	}

	function get($id, $group = 'default')
	{
		$key = $this->key($id, $group);

		if ( isset($this->cache[$key]) )
			$value = $this->cache[$key];
		else
			$value = eaccelerator_get($key);

		$value = maybe_unserialize($value);

		if ( NULL === $value )
			$value = false;

		$this->cache[$key] = $value;

		return $value;
	}

	function set($id, $data, $group = 'default', $expire = 0)
	{
		$key = $this->key($id, $group);
		if ( is_resource($data) )
			return false;

		$data = maybe_serialize($data);

		$result = eaccelerator_put($key, $data, $expire);
		if ( $result )
			$this->cache[$key] = $data;

		return $result;
	}

	function key($key, $group)
	{
		global $blog_id;

		if ( empty($group) )
			$group = 'default';

		if (false !== array_search($group, $this->global_groups))
			$prefix = '';
		else
			$prefix = $blog_id . ':';

		return md5(ABSPATH . "$prefix$group:$key");
	}

	function stats()
	{
		// Note that this is the total eAccelerator stats, not just WP but also any other apps using eAccelerator var storage
		$eaccelerator_info = eaccelerator_info();
		echo "<p>\n";
		echo "<strong>Cached Variables:</strong> {$eaccelerator_info['cachedKeys']}<br/>\n";
		echo "<strong>Cached Scripts:&nbsp;&nbsp;</strong> {$eaccelerator_info['cachedScripts']}<br/>\n";
		echo "</p>\n";

		if ( !empty($this->cache) )
		{
			echo "<pre>\n\r";
			print_r($this->cache);
			echo "</pre>\n\r";
		}
	}

	function WP_Object_Cache()
	{
		// Empty Constructor
	}
}
} //End Else
?>