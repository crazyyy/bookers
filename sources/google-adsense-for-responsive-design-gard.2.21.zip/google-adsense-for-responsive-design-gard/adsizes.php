<?php
$adsizes = array(
    #	Google Adsense Display and Text Unit Sizes
		'970x90'  => 'Large Leaderboard', 
		'728x90'  => 'Leaderboard',
		'468x60'  => 'Banner ',
		'336x280' => 'Large Rectangle',
		'320x100'  => 'Large Mobile Banner',
		'320x50'  => 'Mobile Banner',
		'300x600' => 'Large Skyscraper',
		'300x250' => 'Medium Rectangle',
		'250x250' => 'Square ',
		'234x60'  => 'Half Banner',
		'200x200' => 'Small Square',
		'200x200' => 'Small Square',
		'180x150' => 'Small Rectangle',
		'160x600' => 'Wide Skyscraper',
		'125x125' => 'Button',
		'120x600' => 'Skyscraper',
		'120x240' => 'Vertical Banner',

	#	Google Adsense Link Unit Sizes
		'728x15'  => 'Displays 4 links',
		'468x15'  => 'Displays 4 links',
		'200x90'  => 'Displays 3 links',
		'180x90'  => 'Displays 3 links',
		'160x90'  => 'Displays 3 links',
		'120x90'  => 'Displays 3 links'

);